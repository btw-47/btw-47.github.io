Supplementary material for "Appendix to a paper of B. Williams"

hms-29.mag  Magma script that runs the calculations of the appendix for the
  field Q(sqrt 29)
hms-37.mag  Magma script that runs the calculations of the appendix for the
  field Q(sqrt 37)
blowup.mag  Magma code for working with the blowup of a variety at a point
make_ef.mag  Magma code for finding the Weierstrass model of the general
  fibre of an elliptic fibration and the components of reducible fibres
