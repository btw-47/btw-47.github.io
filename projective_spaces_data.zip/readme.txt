Orthogonal modular forms used in the paper

'Projective spaces as orthogonal modular varieties'

The ***.sobj files can be loaded in Sage (using Python 3) by

L = load('***')

L is a list of OrthogonalModularForms. Please install the package 'weilrep' from
https://github.com/btw-47/weilrep
to compute with these forms.

The corresponding file ***.txt contains a list of
1) the name
2) the principal part of the input function
3) the Fourier expansion

for each element of L.