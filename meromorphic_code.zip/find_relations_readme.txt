This is Sage code which computes relations among modular forms related to orthogonal groups of lattices 2U + L.

**********

REQUIREMENTS
SageMath 9.0 or later
Install the package 'WeilRep' from https://github.com/btw-47/weilrep

**********

Description:
This code computes relations among orthogonal modular forms which are constructed as Eisenstein series or Gritsenko lifts. 
We use the 'pullback trick': the restriction of such a modular form to the span of any lattice vector 'v' can be computed as a paramodular Gritsenko lift of level v^2/2.
To guess relations among orthogonal modular forms, we compute their restrictions to a (user specified) list of lattice vectors, compute the space of relations within each space of paramodular forms, and intersect all of these spaces.

The dimensions of the spaces spanned by the given generators are only * lower bounds * because the relations are not checked to hold on the tube domain for the full lattice 2U+L.
The bound can be improved by increasing the 'precision' or by improving the 'pullback vectors' (see below).

The generators are labelled
e_k (Eisenstein series of weight k)
f_{k, n} (Non cusp form Gritsenko lift #n of weight k)
g_{k, n} (Cusp form Gritsenko lift #n of weight k)
s_{k, a, n} (Singular Gritsenko lift #n of weight k with poles of discriminant at most a)

The output consists of
-- lower bounds for the dimensions
-- potential relations among the generators
in all weights up to the user-specified 'max weight',
and finally a list of potentially 'redundant generators' which can be expressed as polynomials in the other generators.

**********

How to use:

Open the 'find_relations_settings.txt' file.
Above the first row of ***, enter the (positive - definite) lattice L as a 'WeilRep' instance 'w'.
For example, to obtain the root lattice A2, enter either
WeilRep([[2, -1], [-1, 2]])
or
WeilRep(CartanMatrix(['A', 2]))

Enter the generators:
Above the second row of ***, enter the weights of Eisenstein series which are to be considered, separated by commas.
For example, to use Eisenstein series of weights 4, 6, 8, 10 write
4, 6, 8, 10
The weight 'k' must be an even integer at least 4.
If no Eisenstein series are used then leave this line blank.

Above the third row of ***, enter the cuspidal Gritsenko lifts which should be used, in the form
(k, n)
where 'k' is the weight, and 'n' (=1,2,3,...) is the index with respect to the ordering of w.cusp_forms_basis(k - rank(L)/2, ...)
For example, to use the unique cusp form of weight 9 for the root lattice A2, enter
(9, 1)
Pairs (k, n) should be separated by commas.

Above the fourth row of ***, enter the not (necessarily) cuspidal Gritsenko lifts, again in the form
(k, n)
where 'k' is the weight, and 'n' is the index with respect to the ordering of
w.modular_forms_basis(k - rank(L)/2, ...)

Above the fifth row of ***, enter the singular Gritsenko lifts, in the form
(k, a, n)
where 'k' is the weight, 'a' is the maximum possible discriminant of Heegner divisors where these forms have poles, and 'n' (=1,2,3,...) is the index with respect to the ordering of
w.nearly_holomorphic_modular_forms_basis(k - rank(L)/2, a, ...)

Above the sixth row of ***, enter a list of "pullback vectors" separated by semicolons.
This should be a list of integral vectors.
For example, to use pullbacks to the vectors (1, 2) and (2, 1) with respect to the A2 lattice this line should be
[1, 2]; [2, 1]

Above the seventh row of ***, enter the precision to which the input forms should be computed.
(Higher precision is better but makes the algorithm much slower.)

Above the eighth row of ***, enter the maximum weight to which we should find relations.

Finally, enter a filename to which the results should be saved.

Now run 'sage find_relations.sage'!