These files contain the Taylor expansions of modular forms on the unitary group U(L), where L is the Hermitian lattice over ZZ[e^{2 \pi i / 3}] whose underlying ZZ-lattice is

U + U(3) + 2 A_2

These are power series in the variables 'z1' and 'z2' with coefficients in the polynomial ring QQ[e3, s6]. The variables e3, s6 represent the modular forms of level \Gamma_1(3)

e3(\tau) = 1 - 36q - 54q^2 - ... of weight 3

s6(\tau) = \eta(\tau)^6 \eta(3 \tau)^6 = q - 6q^2 +/- ... of weight 6

The files are labelled as followed:
'E6', 'E12', 'E18', 'E24', 'E30' are the restrictions of the Eisenstein series E_k, k \in \{6, 12, 18, 24, 30\} on O(6, 2) to U(3, 1).

For each label there are two files: '*.sobj' and '*.txt'
The '*.txt' file simply contains the power series expansion of the corresponding form as a text file.
The '*.sobj' file can be loaded in Sage (with Python 3) with the command

load('*.sobj')

This is the power series expansion of the corresponding form as a Sage object.