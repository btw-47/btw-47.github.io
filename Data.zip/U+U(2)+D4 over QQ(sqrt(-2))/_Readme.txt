These files contain the Taylor expansions of modular forms on the unitary group U(L), where L is the Hermitian lattice over ZZ[\sqrt{-2}] whose underlying ZZ-lattice is

U + U(2) + D_4

These are power series in the variables 'z1' and 'z2' with coefficients in the polynomial ring QQ[e2, e4]. The variables e2, e4 represent the modular forms of level \Gamma_0(2)

e2(\tau) = 1 + 24q + ... = 2 E_2(2 \tau) - E_2(\tau)

e4(\tau) = 1 + 240q^2 + ... = E_4(2 \tau)

The files are labelled as followed:
'e2', 'e6', 'e10' are the unitary restrictions of the *normalized Eisenstein series* E_k on O(6, 2),  k \in \{2, 6, 10\}.
'f1', 'f2', 'f3', 'f4', 'f5' are the holomorphic Eisenstein series of weight 4. (In the paper these are labelled 'e_1','e_2','e_3','e_4','e_5'
'p2', 'p3', 'p4', 'p5' are the power sums e_1^k + ... + e_5^k, k \in \{2, 3, 4, 5\}.

For each label there are two files: '*.sobj' and '*.txt'
The '*.txt' file simply contains the power series expansion of the corresponding form as a text file.
The '*.sobj' file can be loaded in Sage (with Python 3) with the command

load('*.sobj')

This is the power series expansion of the corresponding form as a Sage object.